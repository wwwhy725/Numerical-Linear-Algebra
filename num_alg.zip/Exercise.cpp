#include "Exercise.h"
#include<ctime>
#include<cstdlib>
#include<windows.h>
#include<chrono>
#include<cmath>
#include<iomanip>

//Homework1
/* 
void exercise_1_1()  //LU分解解方程
{
    //初始化A和b
    int n = 84;
    vector<vector<double>> A = zeros_mat(n, n);
    vector<vector<double>> b = zeros_mat(n, 1);  //注意这里向量也用矩阵形式
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(i == j) A[i][j] = 6;
            if(i == j-1) A[i][j] = 1;
            if(i == j+1) A[i][j] = 8;
        }
    }
    b[0][0] = 7;
    b[n-1][0] = 14;
    for(int i = 1;i < n-1;i++) 
    {
        b[i][0] = 15;
    }

    //LU分解
    cout << "LU:" << endl;
    auto start = chrono::steady_clock::now();
    vector<vector<double>> result = LU_solve(A, b);
    auto end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result);
    cout << endl;

    //计算算出的解与精确解的误差
    vector<vector<double>> x = zeros_mat(n, 1);
    for(int i = 0;i < n;i++) x[i][0] = 1;
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result, x) << endl;
    cout << endl;
}

void exercise_1_2()  //全主元
{
    //初始化A和b
    int n = 84;
    vector<vector<double>> A = zeros_mat(n, n);
    vector<vector<double>> b = zeros_mat(n, 1);  //注意这里向量也用矩阵形式
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(i == j) A[i][j] = 6;
            if(i == j-1) A[i][j] = 1;
            if(i == j+1) A[i][j] = 8;
        }
    }
    b[0][0] = 7;
    b[n-1][0] = 14;
    for(int i = 1;i < n-1;i++) 
    {
        b[i][0] = 15;
    }

    //全主元法解方程
    cout << "full_pivoting:" << endl;
    auto start = chrono::steady_clock::now();
    vector<vector<double>> result = full_pivot_solve(A, b);
    auto end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result);
    cout << endl;

    //计算算出的解与精确解的误差
    vector<vector<double>> x = zeros_mat(n, 1);
    for(int i = 0;i < n;i++) x[i][0] = 1;
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result, x) << endl;
    cout << endl;
}

void exercise_1_3()  //列主元解方程
{
    //初始化A和b
    int n = 84;
    vector<vector<double>> A = zeros_mat(n, n);
    vector<vector<double>> b = zeros_mat(n, 1);  //注意这里向量也用矩阵形式
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(i == j) A[i][j] = 6;
            if(i == j-1) A[i][j] = 1;
            if(i == j+1) A[i][j] = 8;
        }
    }
    b[0][0] = 7;
    b[n-1][0] = 14;
    for(int i = 1;i < n-1;i++) 
    {
        b[i][0] = 15;
    }

    //列主元解方程
    cout << "col_pivoting:" << endl;
    auto start = chrono::steady_clock::now();
    vector<vector<double>> result = col_pivot_solve(A, b);
    auto end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result);
    cout << endl;

    //计算算出的解与精确解的误差
    vector<vector<double>> x = zeros_mat(n, 1);
    for(int i = 0;i < n;i++) x[i][0] = 1;
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result, x) << endl;
    cout << endl;
}

void exercise_2_1()  //随机矩阵b
{
    //初始化A
    int n = 100;
    vector<vector<double>> A = zeros_mat(n, n);
    vector<vector<double>> b = zeros_mat(n, 1);  //注意这里向量也用矩阵形式
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(i == j) A[i][j] = 10;
            if(i == j-1) A[i][j] = 1;
            if(i == j+1) A[i][j] = 1;
        }
    }
    vector<vector<double>> A_ = A, A1 = A;
    //随机生成b（-50到50之间的随机数）
    srand((unsigned)time(NULL));
    for(int i = 0;i < n;i++) b[i][0] = -50 + (int)50 * rand() / (RAND_MAX + 1);
    vector<vector<double>> b_ = b, b1 = b;
    
    //平方根法
    cout << "Cholesky:" << endl;
    auto start = chrono::steady_clock::now();
    vector<vector<double>> result = Cholesky_sol(A, b);
    auto end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result);
    cout << endl;
    //由于不知道精确解，所以用||Ax-b||计算误差
    cout << "||Ax-b|| in the sense of vector 2 norm is:" << vec_norm_2(mat_mult(A_, result), b_) << endl;
    cout << endl;

    //改进的平方根法
    cout << "modified_Cholesky:" << endl;
    start = chrono::steady_clock::now();
    vector<vector<double>> result_ = modified_Cholesky_sol(A_, b_);
    end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result_);
    cout << endl;
    //由于不知道精确解，所以用||Ax-b||计算误差
    cout << "||Ax-b|| in the sense of vector 2 norm is:" << vec_norm_2(mat_mult(A1, result_), b1) << endl;
    cout << endl;
}

void exercise_2_2()  //hilbert
{
    //初始化A和b
    int n = 13;
    vector<vector<double>> A = create_hilbert(n);
    vector<vector<double>> b = zeros_mat(n, 1);
    for(int i = 0;i < n;i++)
    {
        double sum = 0;
        for(int j = 0;j < n;j++)
        {
            sum += 1.0/(i+j+1);
        }
        b[i][0] = sum;
    }
    vector<vector<double>> A_ = A;
    vector<vector<double>> b_ = b;

    ///平方根法
    cout << "Cholesky:" << endl;
    auto start = chrono::steady_clock::now();
    vector<vector<double>> result = Cholesky_sol(A, b);
    auto end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result);
    cout << endl;
    //计算算出的解与精确解的误差
    vector<vector<double>> x = zeros_mat(n, 1);
    for(int i = 0;i < n;i++) x[i][0] = 1;
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result, x) << endl;
    cout << endl;
    //改进的平方根法
    cout << "modified_Cholesky:" << endl;
    start = chrono::steady_clock::now();
    vector<vector<double>> result_ = modified_Cholesky_sol(A_, b_);
    end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result_);
    cout << endl;
    //计算算出的解与精确解的误差
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result_, x) << endl;
    cout << endl;
}

void exercise_3_1()  //用第一题的三个方法解第二题第一问的方程组
{
    //初始化A
    int n = 100;
    vector<vector<double>> A = zeros_mat(n, n);
    vector<vector<double>> b = zeros_mat(n, 1);  //注意这里向量也用矩阵形式
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(i == j) A[i][j] = 10;
            if(i == j-1) A[i][j] = 1;
            if(i == j+1) A[i][j] = 1;
        }
    }
    vector<vector<double>> A_ = A, A1 = A, A2 = A;
    //随机生成b（-50到50之间的随机数）
    srand((unsigned)time(NULL));
    for(int i = 0;i < n;i++) b[i][0] = -50 + (int)50 * rand() / (RAND_MAX + 1);
    vector<vector<double>> b_ = b, b1 = b, b2 = b;

    //LU分解
    cout << "LU:" << endl;
    auto start = chrono::steady_clock::now();
    vector<vector<double>> result = LU_solve(A, b);
    auto end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result);
    cout << endl;
    //计算||AX-B||
    cout << "||Ax-b|| in the sense of vector 2 norm is:" << vec_norm_2(mat_mult(A_, result), b_) << endl;
    cout << endl;

    //全主元法解方程
    cout << "full_pivoting:" << endl;
    start = chrono::steady_clock::now();
    vector<vector<double>> result_ = full_pivot_solve(A_, b_);
    end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result_);
    cout << endl;
    //计算||AX-B||
    cout << "||Ax-b|| in the sense of vector 2 norm is:" << vec_norm_2(mat_mult(A1, result_), b1) << endl;
    cout << endl;

    //列主元解方程
    cout << "col_pivoting:" << endl;
    start = chrono::steady_clock::now();
    vector<vector<double>> result1 = col_pivot_solve(A1, b1);
    end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result1);
    cout << endl;
    //计算||AX-B||
    cout << "||Ax-b|| in the sense of vector 2 norm is:" << vec_norm_2(mat_mult(A2, result1), b2) << endl;
    cout << endl;
}

void exercise_3_2()  //用第一题的三个方法解第二题第二问的方程组
{
    //初始化A和b
    int n = 40;
    vector<vector<double>> A = create_hilbert(n);
    vector<vector<double>> b = zeros_mat(n, 1);
    for(int i = 0;i < n;i++)
    {
        double sum = 0;
        for(int j = 0;j < n;j++)
        {
            sum += 1.0/(i+j+1);
        }
        b[i][0] = sum;
    }
    vector<vector<double>> A_ = A, A1 = A;
    vector<vector<double>> b_ = b, b1 = b;

    //LU分解
    cout << "LU:" << endl;
    auto start = chrono::steady_clock::now();
    vector<vector<double>> result = LU_solve(A, b);
    auto end = chrono::steady_clock::now();
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result);
    cout << endl;
    //计算误差
    vector<vector<double>> x = zeros_mat(n, 1);
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result, x) << endl;
    cout << endl;

    //全主元法解方程
    cout << "full_pivoting:" << endl;
    start = chrono::steady_clock::now();
    vector<vector<double>> result_ = full_pivot_solve(A_, b_);
    end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result_);
    cout << endl;
    //计算误差
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result_, x) << endl;
    cout << endl;
 
    //列主元解方程
    cout << "col_pivoting:" << endl;
    start = chrono::steady_clock::now();
    vector<vector<double>> result1 = col_pivot_solve(A1, b1);
    end = chrono::steady_clock::now();   
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;
    cout_mat(result1);
    cout << endl;
    //计算误差
    cout << "error in the sense of vector 2 norm is:" << vec_norm_2(result1, x) << endl;
    cout << endl;
}
 */

//Homework2
/* 
void exercise_1_1()  //5到20阶hilbert矩阵无穷范数条件数
{
    for(int i = 5;i < 21;i++)
    {
        cout << i << ": " << kay_inf(create_hilbert(i)) << endl;
    }
}

void exercise_1_2()
{
    cout << "precision" << "\t" << "real error" << endl;
    for(int n = 5;n < 31;n++)
    {
        //生成A
        vector<vector<double>> A = zeros_mat(n, n);
        for(int i = 0;i < n;i++)
        {
            for(int j = 0;j < n;j++)
            {
                if(i == j or j == n-1) A[i][j] = 1;
                else if (i > j) A[i][j] = -1;
                else A[i][j] = 0;
            }
        }
        //rand_max 随机数
        vector<vector<double>> x = zeros_mat(n, 1);
        for (int i = 0; i < n; i++)
        {
            x[i][0] = double(rand()) / (RAND_MAX)*100.0;
        }
        vector<vector<double>> b = mat_mult(A, x), b1 = mat_mult(A, x);
        vector<vector<double>> A1 = A;
        int posi1 = 0, posi2 = 0;
        double b_inf = vec_norm_inf(b, posi1);                 //算b的无穷范数
        double kay_A = kay_inf(A);                             //算A的条件数
        vector<vector<double>> result = col_pivot_solve(A, b); //解方程
        double r_inf = vec_norm_inf(mat_minus(b1, mat_mult(A1, result)), posi2);
        double error = vec_norm_inf(mat_minus(result, x), posi1)/vec_norm_inf(x, posi2);
        printf("%.6e\t", kay_A * r_inf / b_inf);
        printf("%.6e", error);
    }
}
 */

//Homework3
/* 
void exercise_1_1()  //QR分解解第一章的三个方程
{
   //初始化A和b
    int n = 84;
    vector<vector<double>> A = zeros_mat(n, n);
    vector<vector<double>> b = zeros_mat(n, 1);  //注意这里向量也用矩阵形式
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(i == j) A[i][j] = 6;
            if(i == j-1) A[i][j] = 1;
            if(i == j+1) A[i][j] = 8;
        }
    }
    b[0][0] = 7;
    b[n-1][0] = 14;
    for(int i = 1;i < n-1;i++) 
    {
        b[i][0] = 15;
    }
    vector<vector<double>> A1 = A,A2 = A,A3 = A,A4 = A,A5 = A;
    vector<vector<double>> b1 = b,b2 = b,b3 = b,b4 = b,b5 = b;

    //解方程
    vector<vector<double>> result = QR_solve(A, b);
    cout_mat(result);
}

void exercise_1_2()
{
    //初始化A
    int n = 100;
    vector<vector<double>> A = zeros_mat(n, n);
    vector<vector<double>> b = zeros_mat(n, 1);  //注意这里向量也用矩阵形式
    vector<vector<double>> x = zeros_mat(n, 1);
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(i == j) A[i][j] = 10;
            if(i == j-1) A[i][j] = 1;
            if(i == j+1) A[i][j] = 1;
        }
    }
    //随机生成b
    srand((unsigned)time(NULL));
    for(int i = 0;i < n;i++) b[i][0] = double(rand()) / (RAND_MAX)*100.0;
    vector<vector<double>> A1 = A, A2 = A, A3 = A, A4 = A,A5 = A, b1 = b, b2 = b, b3 = b;

    //解方程
    vector<vector<double>> result = QR_solve(A, b);
    cout_mat(result);
}

void exercise_1_3()
{
    //初始化A和b
    int n = 40;
    vector<vector<double>> A = create_hilbert(n);
    vector<vector<double>> b = zeros_mat(n, 1);
    for(int i = 0;i < n;i++)
    {
        double sum = 0;
        for(int j = 0;j < n;j++)
        {
            sum += 1.0/(i+j+1);
        }
        b[i][0] = sum;
    }
    vector<vector<double>> A1 = A,A2 = A,A3 = A,A4 = A,A5 = A;
    vector<vector<double>> b1 = b,b2 = b,b3 = b,b4 = b,b5 = b;

    //解方程
    vector<vector<double>> result = QR_solve(A, b);
    cout_mat(result);
}

void exercise_2()
{
    vector<vector<double>> t = {{-1},{-0.75},{-0.5},{0},{0.25},{0.5},{0.75}};
	vector<vector<double>> y = {{1},{0.8125},{0.75},{1},{1.3125},{1.75},{2.3125}};
    vector<vector<double>> A = zeros_mat(7, 3);
    for(int i = 0;i < 7;i++) 
    {
        for(int j = 0;j < 3;j++)
        {
            if(j == 0) A[i][j] = t[i][0]*t[i][0];
            else if (j == 1) A[i][j] = t[i][0];
            else A[i][j] = 1;
        }
    }
    double error = 0;
    vector<vector<double>> result = LS(A, y, error);
    cout_mat(result);
    cout << "error is " << error << endl;
}

void exercise_3()
{
    //输入数据
    vector<vector<double>> A =
	{ {1,4.9176, 1, 3.472, 0.998, 1, 7, 4, 42, 3, 1, 0},
	{1,5.0208, 1, 3.531, 1.5, 2, 7, 4, 62, 1, 1, 0},
	{1,4.5429, 1, 2.275, 1.175, 1, 6, 3, 40,  2, 1, 0},
	{1,4.5573, 1, 4.05, 1.232, 1, 6, 3, 54, 4, 1, 0},
	{1,5.0597, 1, 4.455, 1.121, 1, 6, 3, 42, 3, 1, 0},
	{1,3.891, 1, 4.455, 0.988, 1, 6, 3, 56, 2, 1, 0},
	{1,5.898, 1, 5.85, 1.24, 1, 7, 3, 51, 2, 1,  1},
	{1,5.6039, 1, 9.52, 1.501, 0, 6, 3, 32, 1, 1, 0},
	{1,15.4202, 2.5,  9.8, 3.42, 2, 10, 5, 42, 2, 1, 1},
	{1,14.4598, 2.5, 12.8, 3, 2, 9, 5, 14, 4, 1, 1},
	{1,5.8282, 1, 6.435, 1.225, 2, 6, 3, 32, 1, 1, 0},
	{1,5.3003, 1, 4.9883, 1.552, 1, 6, 3, 30, 1, 2, 0},
	{1,6.2712, 1, 5.52, 0.975, 1, 5, 2, 30, 1, 2, 0},
	{1,5.9592, 1, 6.666, 1.121, 2, 6, 3, 32, 2, 1, 0},
	{1,5.05, 1, 5, 1.02, 0, 5, 2, 46, 4, 1, 1},
	{1,5.6039, 1, 9.52, 1.501, 0, 6, 3, 32, 1, 1, 0},
	{1,8.2464, 1.5, 5.15, 1.664, 2, 8, 4, 50, 4, 1, 0},
	{1,6.6969, 1.5, 6.092, 1.488, 1.5, 7, 3, 22, 1, 1, 1},
	{1,7.7841, 1.5, 7.102, 1.376, 1, 6, 3, 17, 2, 1, 0},
	{1,9.0384, 1, 7.8, 1.5, 1.5, 7, 3, 23, 3, 3, 0},
	{1,5.9894, 1, 5.52, 1.256, 2, 6, 3, 40, 4, 1, 1},
	{1,7.5422, 1.5, 4, 1.69, 1, 6, 3, 22, 1, 1, 0},
	{1,8.7951, 1.5, 9.89, 1.82, 2, 8, 4, 50, 1, 1, 1},
	{1,6.0931, 1.5, 6.7265, 1.652, 1, 6, 3, 44, 4, 1, 0},
	{1,8.3607, 1.5, 9.15, 1.777, 2., 8, 4, 48, 1, 1, 1},
	{1,8.14, 1, 8, 1.504, 2, 7, 3, 3, 1, 3, 0},
	{1,9.1416, 1.5, 7.3262, 1.831, 1.5, 8, 4, 31, 4, 1, 0},
	{1,12, 1.5, 5, 1.2, 2, 6, 3, 30, 3, 1, 1} };
	vector<double> b_ =
	{25.9, 29.5, 27.9, 25.9, 29.9, 29.9, 30.9,
	28.9, 84.9, 82.9, 35.9, 31.5, 31.0, 30.9,
	30.0, 28.9, 36.9, 41.9, 40.5, 43.9, 37.5,
	37.9, 44.5, 37.9, 38.9, 36.9, 45.8, 41.0};
    vector<vector<double>> b = zeros_mat(b_.size(), 1);
    for(int i = 0;i < b_.size();i++) b[i][0] = b_[i];

    //最小二乘
    double error = 0;
    vector<vector<double>> result = LS(A, b, error);
    cout_mat(result);
    cout << "error is " << error << endl;
}
 */

//Homework4
/* 
void exercise_1()
{
    int n = 100;
    int N = n - 1;
    double epsilon = 1, a = 0.5, h = 1.0/n, w = 1.9;  //epsilon = 0.0001,w = 1.1;epsilon = 0.01,w = 1.5;
    cout << "epsilon = " << epsilon << endl;

    //创建矩阵A,b
    vector<vector<double>> A = zeros_mat(N, N);
    vector<vector<double>> b = zeros_mat(N, 1);
    for(int i=0;i<N-1;i++){//初始化系数矩阵A和有端项b
        A[i][i]=-(2*epsilon+h);
        A[i][i+1]=epsilon+h;
        A[i+1][i]=epsilon;
        b[i][0]=a*h*h;
    }
    A[N-1][N-1]=-(2*epsilon+h);
    b[N-1][0]=a*h*h-(epsilon+h);
    
    //搞出D逆,L,U
    vector<vector<double>> D_inv = zeros_mat(N, N);
    for(int i = 0;i < N;i++)  D_inv[i][i] = 1.0/A[i][i];
    vector<vector<double>> B = mat_minus(identity_mat(N), mat_mult(D_inv, A));
    vector<vector<double>> g = mat_mult(D_inv, b);

    //真实值
    vector<vector<double>> real = zeros_mat(N, 1);
    for(int i=0;i<N;i++)
    {
        real[i][0]=(1.0-a)*(1.0-exp(-(h*i+h)/epsilon))/(1.0-exp(-1.0/epsilon))+a*(h*i+h);//精确解
    }

    //jacobi
    vector<vector<double>> x = zeros_mat(N, 1);
    for(int i = 0;i < N;i++) x[i][0] = 1.0;
    cout << "Jacobi:" << endl;
    auto start = chrono::steady_clock::now();
    Jacobi(B,g,x);
    auto end = chrono::steady_clock::now(); 
    cout_mat(x);
    cout << "error in norm2: " << vec_norm_2(x, real) << endl;  //误差
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << "seconds" << endl;  //时间
    cout << endl;
    //G-S
    for(int i = 0;i < N;i++) x[i][0] = 1.0;
    cout << "G_S:" << endl;
    start = chrono::steady_clock::now();
    G_S(B,g,x);
    end = chrono::steady_clock::now(); 
    cout_mat(x);
    cout << "error in norm2: " << vec_norm_2(x, real) << endl;  //误差
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << "seconds" << endl;  //时间
    cout << endl;
    //SOR
    for(int i = 0;i < N;i++) x[i][0] = 1.0;
    cout << "SOR with omega = " << w << endl;
    start = chrono::steady_clock::now();
    SOR(B,g,x,w);
    end = chrono::steady_clock::now(); 
    cout_mat(x);
    cout << "error in norm2: " << vec_norm_2(x, real) << endl;  //误差
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << "seconds" << endl;  //时间
}

void exercise_2()//不拉直，直接用递推式迭代
{
    int n = 60;
    double h = 1.0/n, w = 1.9;  //n = 20,w = 1.73;n = 40,w = 1.85;n = 60,w = 1.9
    //初始化U
    vector<vector<double>> U = zeros_mat(n+1, n+1), U1, U2;
    for(int i = 0;i < n+1;i++)
    {
        for(int j = 0;j < n+1;j++)
        {
            if(i == 0 or j == 0 or i == n or j == n) U[i][j] = 1;
            else U[i][j] = 0.5;
        }
    }
    U1 = U, U2 = U;
    //Jacobi
    cout << "Jacobi: " << endl;
    auto start = chrono::steady_clock::now();
    new_Jacobi(U, n);
    auto end = chrono::steady_clock::now();
    cout_mat(U);
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << "seconds" << endl;  //时间
    cout << endl;
    //G_S
    cout << "G-S: " << endl;
    start = chrono::steady_clock::now();
    new_G_S(U1, n);
    end = chrono::steady_clock::now();
    cout_mat(U1);
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << "seconds" << endl;  //时间
    cout << endl;
    //SOR
    cout << "SOR with w = " << w << endl;
    start = chrono::steady_clock::now();
    new_SOR(U2, n, w);
    end = chrono::steady_clock::now(); 
    cout_mat(U2);
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << "seconds" << endl;  //时间
    cout << endl;
}
 */

//Homework5
/* 
void exercise_1()
{
    int n = 20;
    int N = (n-1)*(n-1);
    double h = 1.0/n, w = 1.9;
    //初始化A和b
    vector<vector<double>> A = zeros_mat(N, N), b = zeros_mat(N, 1);
    for(int i = 0;i < N - 1;i++)
    {
        A[i][i] = 1+h*h/4;
        A[i][i+1] = -1.0/4;
        A[i+1][i] = -1.0/4;
        if(i+n-1 < N-1) {A[i][i+n-1] = -1.0/4;A[i+n-1][i] = -1.0/4;}
        if(!((i+1)% (n-1)) ) {A[i][i+1] = 0;A[i+1][i] = 0;}
    }
    A[N-1][N-1] = 1 + h*h/4;
    A[N-1][N-n] = -1.0/4;A[N-n][N-1] = -1.0/4;
    int i = 0,j = 0;
    for(int ii = 0;ii < N;ii++)
    {
        j = (ii+1)%(n-1);
        if(j == 0) j = n-1;
        i = (ii+1-j)/(n-1) + 1;
        //cout << "i,j= " << i << j << endl;
        b[ii][0] += h*h/4*sin(i*h*j*h);
        //cout << b[ii][0] << "  ";
        if(i == 1) b[ii][0] += 1.0/4*pow(j*h, 2);
        if(j == 1) b[ii][0] += 1.0/4*pow(i*h, 2);
        if(i == n-1) b[ii][0] += 1.0/4*pow(n*h, 2) + 1.0/4*pow(j*h, 2);
        if(j == n-1) b[ii][0] += 1.0/4*pow(i*h, 2) + 1.0/4*pow(n*h, 2);
        //cout << "b=" << b[ii][0] << endl;
    }
    //搞出B,g
    vector<vector<double>> D_inv = zeros_mat(N, N);
    for(int i = 0;i < N;i++)  D_inv[i][i] = 1.0/A[i][i];
    vector<vector<double>> B = mat_minus(identity_mat(N), mat_mult(D_inv, A));
    vector<vector<double>> g = mat_mult(D_inv, b);
    //初始化x
    vector<vector<double>> x = zeros_mat(N, 1);
    for(int i = 0;i < N;i++) x[i][0] = 1;
    //CG求解方程
    cout << "CG: " << endl;
    conj_grad(A, b, x);
    cout_mat(x);
    //SOR求解方程
    cout << "SOR: " << endl;
    for(int i = 0;i < N;i++) x[i][0] = 1;
    SOR(B, g, x, w);
    cout_mat(x);
}

void exercise_2()
{
    int n = 20;
    vector<vector<double>> A, b, x;
    double temp = 0.0;
    for(int k = 1;k <= 4;k++)
    {
        cout << "n = " << n << endl;
        A = create_hilbert(n), b = zeros_mat(n, 1), x = zeros_mat(n, 1);
        for(int i = 0;i < n;i++)
        {
            for(int j = 0;j < n;j++) temp += A[i][j];
            b[i][0] = 1.0/3*temp;
            temp = 0;
        }
        conj_grad(A, b, x);
        cout_mat(x);
        n += 20;
        cout << endl;
    }
}

void exercise_3()
{
    int N = 5;
    vector<vector<double>> A = {{10,1,2,3,4},{1,9,-1,2,-3},{2,-1,7,3,-5},{3,2,3,12,-1},{4,-3,-5,-1,15}}, b = {{12},{-27},{14},{-17},{12}};
    vector<vector<double>> x = zeros_mat(N, 1);
    //搞出B和g
    vector<vector<double>> D_inv = zeros_mat(N, N);
    for(int i = 0;i < N;i++)  D_inv[i][i] = 1.0/A[i][i];
    vector<vector<double>> B = mat_minus(identity_mat(N), mat_mult(D_inv, A));
    vector<vector<double>> g = mat_mult(D_inv, b);
    //Jacobi
    cout << "Jacobi: " << endl;
    Jacobi(B, g, x);
    cout_mat(x);
    //G-S
    for(int i = 0;i < N;i++) x[i][0] = 0.5;
    cout << "G-S: " << endl;
    G_S(B, g, x);
    cout_mat(x);
    //CG
    x = zeros_mat(N, 1);
    cout << "CG: " << endl;
    conj_grad(A, b, x);
    cout_mat(x);
}
 */

//Homework6
/* 
void exercise_1()
{
    vector<double> a = {3, -5, 1}, b = {-1, -3, 0}, c = {-1000, 790, -99902, 79108.9, 9802.08, 10891.01, 208.01, 101};
    int times = 1000;
    double x = find_largest_root(a, times);
    cout << "the largest root is " << x << endl << endl;
    x = find_largest_root(b, times);
    cout << "the largest root is " << x << endl << endl;
    x = find_largest_root(c, times);
    cout << "the largest root is " << x << endl << endl;
}

void exercise_2_1()
{
    vector<vector<double>> A = zeros_mat(41, 41);
	A[0][40] = -1;
	A[3][40] = -1;
	for (int i = 1; i < 41; i++) A[i][i - 1] = 1;
    eigenvalue(A);
}

void exercise_2_2()
{
    double x, a, b;
    vector<vector<double>> A;
    for(int i = 0;i < 3;i++)
    {
        x = 0.9+i*0.1;
        cout << "result of x = " << x << " :" << endl;
        A = { {9.1,3.0,2.6,4.0},{4.2,5.3,4.7,1.6},{3.2,1.7,9.4,x},{6.1,4.9,3.5,6.2} };
        eigenvalue(A);
    }
}
 */

//Homework7
/* 
void exercise_1()//过关Jacobi
{
    int n = 50;
    for(int i = 0;i < 6;i++)
    {
        n = 50+i*10;
        cout << "n: " << n << endl;
        vector<vector<double>> A = zeros_mat(n, n);
        for(int i = 0;i < n;i++)
        {
            A[i][i] = 4;
            if(i != 0)
            {
                A[i-1][i] = 1;
                A[i][i-1] = 1;
            }
        }
        eigen_of_tri_diag(A);
    }
}

void exercise_2()//二分法
{
    int n = 100;
    vector<vector<double>> T = zeros_mat(n, n);
    for(int i = 0;i < n;i++)
    {
        T[i][i] = 2;
        if(i != 0)
        {
            T[i-1][i] = -1;
            T[i][i-1] = -1;
        }
    }
    dichotomy_and_reverse_power(T);
}
 */

//SVD

void exercise_1()
{
    vector<vector<double>> A = { {1.0000000000,4.9176000000,1.0000000000,3.4720000000,0.9980000000,1.0000000000,7.0000000000,4.0000000000,42.0000000000,3.0000000000,1.0000000000,0.0000000000},{1.0000000000,5.0208000000,1.0000000000,3.5310000000,1.5000000000,2.0000000000,7.0000000000,4.0000000000,62.0000000000,1.0000000000,1.0000000000,0.0000000000},{1.0000000000,4.5429000000,1.0000000000,2.2750000000,1.1750000000,1.0000000000,6.0000000000,3.0000000000,40.0000000000,2.0000000000,1.0000000000,0.0000000000},{1.0000000000,4.5573000000,1.0000000000,4.0500000000,1.2320000000,1.0000000000,6.0000000000,3.0000000000,54.0000000000,4.0000000000,1.0000000000,0.0000000000},{1.0000000000,5.0597000000,1.0000000000,4.4550000000,1.1210000000,1.0000000000,6.0000000000,3.0000000000,42.0000000000,3.0000000000,1.0000000000,0.0000000000},{1.0000000000,3.8910000000,1.0000000000,4.4550000000,0.9880000000,1.0000000000,6.0000000000,3.0000000000,56.0000000000,2.0000000000,1.0000000000,0.0000000000},{1.0000000000,5.8980000000,1.0000000000,5.8500000000,1.2400000000,1.0000000000,7.0000000000,3.0000000000,51.0000000000,2.0000000000,1.0000000000,1.0000000000},{1.0000000000,5.6039000000,1.0000000000,9.5200000000,1.5010000000,0.0000000000,6.0000000000,3.0000000000,32.0000000000,1.0000000000,1.0000000000,0.0000000000},{1.0000000000,15.4202000000,2.5000000000,9.8000000000,3.4200000000,2.0000000000,10.0000000000,5.0000000000,42.0000000000,2.0000000000,1.0000000000,1.0000000000},{1.0000000000,14.4598000000,2.5000000000,12.8000000000,3.0000000000,2.0000000000,9.0000000000,5.0000000000,14.0000000000,4.0000000000,1.0000000000,1.0000000000},{1.0000000000,5.8282000000,1.0000000000,6.4350000000,1.2250000000,2.0000000000,6.0000000000,3.0000000000,32.0000000000,1.0000000000,1.0000000000,0.0000000000},{1.0000000000,5.3003000000,1.0000000000,4.9883000000,1.5520000000,1.0000000000,6.0000000000,3.0000000000,30.0000000000,1.0000000000,2.0000000000,0.0000000000},{1.0000000000,6.2712000000,1.0000000000,5.5200000000,0.9750000000,1.0000000000,5.0000000000,2.0000000000,30.0000000000,1.0000000000,2.0000000000,0.0000000000},{1.0000000000,5.9592000000,1.0000000000,6.6660000000,1.1210000000,2.0000000000,6.0000000000,3.0000000000,32.0000000000,2.0000000000,1.0000000000,0.0000000000},{1.0000000000,5.0500000000,1.0000000000,5.0000000000,1.0200000000,0.0000000000,5.0000000000,2.0000000000,46.0000000000,4.0000000000,1.0000000000,1.0000000000},{1.0000000000,5.6039000000,1.0000000000,9.5200000000,1.5010000000,0.0000000000,6.0000000000,3.0000000000,32.0000000000,1.0000000000,1.0000000000,0.0000000000},{1.0000000000,8.2464000000,1.5000000000,5.1500000000,1.6640000000,2.0000000000,8.0000000000,4.0000000000,50.0000000000,4.0000000000,1.0000000000,0.0000000000},{1.0000000000,6.6969000000,1.5000000000,6.0920000000,1.4880000000,1.5000000000,7.0000000000,3.0000000000,22.0000000000,1.0000000000,1.0000000000,1.0000000000},{1.0000000000,7.7841000000,1.5000000000,7.1020000000,1.3760000000,1.0000000000,6.0000000000,3.0000000000,17.0000000000,2.0000000000,1.0000000000,0.0000000000},{1.0000000000,9.0384000000,1.0000000000,7.8000000000,1.5000000000,1.5000000000,7.0000000000,3.0000000000,23.0000000000,3.0000000000,3.0000000000,0.0000000000},{1.0000000000,5.9894000000,1.0000000000,5.5200000000,1.2560000000,2.0000000000,6.0000000000,3.0000000000,40.0000000000,4.0000000000,1.0000000000,1.0000000000},{1.0000000000,7.5422000000,1.5000000000,4.0000000000,1.6900000000,1.0000000000,6.0000000000,3.0000000000,22.0000000000,1.0000000000,1.0000000000,0.0000000000},{1.0000000000,8.7951000000,1.5000000000,9.8900000000,1.8200000000,2.0000000000,8.0000000000,4.0000000000,50.0000000000,1.0000000000,1.0000000000,1.0000000000},{1.0000000000,6.0931000000,1.5000000000,6.7265000000,1.6520000000,1.0000000000,6.0000000000,3.0000000000,44.0000000000,4.0000000000,1.0000000000,0.0000000000},{1.0000000000,8.3607000000,1.5000000000,9.1500000000,1.7770000000,2.0000000000,8.0000000000,4.0000000000,48.0000000000,1.0000000000,1.0000000000,1.0000000000},{1.0000000000,8.1400000000,1.0000000000,8.0000000000,1.5040000000,2.0000000000,7.0000000000,3.0000000000,3.0000000000,1.0000000000,3.0000000000,0.0000000000},{1.0000000000,9.1416000000,1.5000000000,7.3262000000,1.8310000000,1.5000000000,8.0000000000,4.0000000000,31.0000000000,4.0000000000,1.0000000000,0.0000000000},{1.0000000000,12.0000000000,1.5000000000,5.0000000000,1.2000000000,2.0000000000,6.0000000000,3.0000000000,30.0000000000,3.0000000000,1.0000000000,1.0000000000} };
    //int m = A.size(), n = A[0].size();
    //vector<vector<double>> U = identity_mat(m), V = identity_mat(n), A1 = A, temp;
    //bi_diag(A, U, V);
    //cout_mat(A);
    //temp = mat_minus(mat_mult(mat_mult(U, A1), V), A);
    //cout_mat(U);
    SVD(A);
    
}
