#pragma once
#include <iostream>
#include <vector>
#include<Windows.h>
#include"Function.h"
#include<stdlib.h>
#include <time.h>
#include<iomanip>

//Homework1
/* void exercise_1_1();

void exercise_1_2();

void exercise_1_3();

void exercise_2_1();

void exercise_2_2();

void exercise_3_1();

void exercise_3_2(); */

//Homework2
/* void exercise_1_1();

void exercise_1_2(); */

//Homework3
/* void exercise_1_1();

void exercise_1_2();

void exercise_1_3();

void exercise_2();

void exercise_3(); */

//Homework4
/* void exercise_1();  //Jacobi迭代解方程

void exercise_2(); */

//Homework5
/* void exercise_1();

void exercise_2();

void exercise_3(); */

//Homework6
/* void exercise_1();

void exercise_2_1();

void exercise_2_2(); */

//Homework7
/* void exercise_1();

void exercise_2(); */

//SVD
void exercise_1();
